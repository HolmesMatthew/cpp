#include "character.h"
#include <iostream>
